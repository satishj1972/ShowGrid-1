# 🔥 SHOWGRID FIREBASE SETUP GUIDE
## Complete Step-by-Step Configuration

---

# 📋 CHECKLIST

- [ ] Create Firebase Project
- [ ] Add Android App to Firebase
- [ ] Enable Authentication (Phone + Google)
- [ ] Create Firestore Database
- [ ] Setup Cloud Storage
- [ ] Install FlutterFire CLI
- [ ] Run `flutterfire configure`
- [ ] Update Android config files
- [ ] Add security rules
- [ ] Test authentication

---

# STEP 1: CREATE FIREBASE PROJECT

1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. Click **"Add project"**
3. Project name: **`ShowGrid`** (or `showgrid-app`)
4. Enable/Disable Google Analytics (your choice)
5. Click **Create Project**
6. Wait for creation to complete

---

# STEP 2: ADD ANDROID APP

1. In Firebase Console, click the **Android icon**
2. Fill in:
   - **Package name:** `com.showgrid.app`
   - **App nickname:** `ShowGrid`
   - **SHA-1:** (Optional for now, needed for Google Sign-In later)
3. Click **Register app**
4. **Download `google-services.json`**
5. Skip the remaining steps (we'll use FlutterFire)

### Getting SHA-1 (for Google Sign-In)
```bash
# In your project directory
cd android
./gradlew signingReport

# Look for "SHA1" under "debug" variant
# Copy that value to Firebase Console > Project Settings > Your Apps > SHA certificate fingerprints
```

---

# STEP 3: ENABLE AUTHENTICATION

1. Go to **Build → Authentication**
2. Click **Get Started**
3. Enable **Phone** authentication:
   - Click Phone → Enable → Save
4. Enable **Google** authentication:
   - Click Google → Enable
   - Add your email as support email
   - Save

---

# STEP 4: CREATE FIRESTORE DATABASE

1. Go to **Build → Firestore Database**
2. Click **Create database**
3. Select **Start in test mode** (we'll add rules later)
4. Choose a location (e.g., `asia-south1` for India)
5. Click **Enable**

### Initial Collections to Create
Click **Start collection** and create:

**Collection: `challenges`** (Fortune Grid)
```
Document ID: auto
Fields:
  - title: "Dance Challenge"
  - description: "Show your best moves"
  - imageUrl: "https://..."
  - isActive: true
  - startDate: (timestamp)
  - endDate: (timestamp)
  - mediaType: "video"
  - maxDuration: 60
  - createdAt: (timestamp)
```

**Collection: `episodes`** (Fanverse)
```
Document ID: auto
Fields:
  - title: "Iconic Movie Scene"
  - description: "Recreate this famous scene"
  - referenceUrl: "https://..."
  - isActive: true
  - mediaType: "video"
  - createdAt: (timestamp)
```

**Collection: `chapters`** (GridVoice)
```
Document ID: auto
Fields:
  - title: "My City Story"
  - description: "Tell us about your city"
  - isActive: true
  - mediaType: "audio"
  - maxDuration: 180
  - createdAt: (timestamp)
```

---

# STEP 5: SETUP CLOUD STORAGE

1. Go to **Build → Storage**
2. Click **Get Started**
3. Select **Start in test mode**
4. Choose same location as Firestore
5. Click **Done**

---

# STEP 6: INSTALL FLUTTERFIRE CLI

Run these commands in your Codespace:

```bash
# Install Firebase CLI (Node.js tool)
npm install -g firebase-tools

# Login to Firebase
firebase login

# Install FlutterFire CLI (Dart tool)
dart pub global activate flutterfire_cli

# Add to PATH (add this to your .bashrc for persistence)
export PATH="$PATH":"$HOME/.pub-cache/bin"

# Verify installation
flutterfire --version
```

---

# STEP 7: CONFIGURE FIREBASE FOR FLUTTER

```bash
# Make sure you're in the project root
cd /workspaces/ShowGrid-1

# Run FlutterFire configuration
flutterfire configure

# When prompted:
# 1. Select your ShowGrid project
# 2. Select platforms: Android, Web (iOS if applicable)
# 3. Confirm the configuration
```

This creates:
- `lib/firebase_options.dart` - Platform configuration
- Updates `android/app/google-services.json`

---

# STEP 8: UPDATE ANDROID CONFIGURATION

### android/build.gradle
Add the Google Services classpath:
```gradle
buildscript {
    dependencies {
        // Add this line
        classpath 'com.google.gms:google-services:4.4.0'
    }
}
```

### android/app/build.gradle
Add at the top:
```gradle
plugins {
    id "com.android.application"
    id "kotlin-android"
    id "dev.flutter.flutter-gradle-plugin"
    id "com.google.gms.google-services"  // Add this
}
```

Update defaultConfig:
```gradle
defaultConfig {
    applicationId "com.showgrid.app"
    minSdk 23  // Required for Firebase
    multiDexEnabled true  // Required for video_compress
}
```

---

# STEP 9: ADD SECURITY RULES

### Firestore Rules
Go to **Firestore → Rules** and paste:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Allow read access to all documents
    match /{document=**} {
      allow read: if true;
    }
    
    // Users can only write to their own documents
    match /users/{userId} {
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Authenticated users can create entries
    match /entries/{entryId} {
      allow create: if request.auth != null;
      allow update, delete: if request.auth != null && 
        resource.data.userId == request.auth.uid;
    }
  }
}
```

### Storage Rules
Go to **Storage → Rules** and paste:
```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{allPaths=**} {
      allow read: if true;
      allow write: if request.auth != null;
    }
  }
}
```

---

# STEP 10: TEST YOUR SETUP

```bash
# Get dependencies
flutter pub get

# Run on web (easiest test in Codespaces)
flutter run -d web-server --web-port 3000
```

---

# 📁 FILES CREATED

| File | Purpose |
|------|---------|
| `lib/core/services/auth_service.dart` | Phone & Google authentication |
| `lib/core/services/firestore_service.dart` | Database operations |
| `lib/core/services/storage_service.dart` | Media upload/download |
| `lib/main.dart` | Updated with Firebase init |
| `pubspec.yaml` | Updated with Firebase deps |
| `firestore.rules` | Database security rules |
| `storage.rules` | Storage security rules |

---

# 🚀 QUICK COMMANDS

```bash
# Check Firebase connection
firebase projects:list

# Deploy Firestore rules
firebase deploy --only firestore:rules

# Deploy Storage rules
firebase deploy --only storage:rules

# View Firebase logs
firebase functions:log
```

---

# ❓ TROUBLESHOOTING

### "No Firebase App has been created"
```dart
// Make sure Firebase.initializeApp() is called before runApp()
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(MyApp());
}
```

### "google-services.json not found"
```bash
# Re-run FlutterFire configuration
flutterfire configure
```

### "MissingPluginException"
```bash
# Clean and rebuild
flutter clean
flutter pub get
```

### Phone Auth not working
- Make sure Phone provider is enabled in Firebase Console
- Add SHA-1 fingerprint for Android
- Check if phone number format includes country code (+91...)

---

# 📞 NEXT STEPS AFTER SETUP

1. **Integrate Auth in Login Screen**
   - Connect OTP screen to `AuthService.sendOTP()`
   - Handle verification in `AuthService.verifyOTP()`

2. **Connect Media Upload**
   - Use `StorageService.uploadPhoto()` in capture screens
   - Use `StorageService.uploadVideo()` for video entries
   - Use `StorageService.uploadAudio()` for GridVoice

3. **Load Real Data**
   - Replace mock data with Firestore streams
   - Use `FirestoreService.streamActiveChallenges()`

4. **Add AI Scoring** (Later)
   - Integrate OpenAI Vision API or Google Cloud Vision
   - Update scores via `FirestoreService.updateAIScore()`

---

**Document Version:** 1.0
**Last Updated:** January 2025
