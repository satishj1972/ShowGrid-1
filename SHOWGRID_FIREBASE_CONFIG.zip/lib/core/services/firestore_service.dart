// lib/core/services/firestore_service.dart
// Firestore Database Service for ShowGrid

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

// ============================================
// FIRESTORE SERVICE PROVIDER
// ============================================
final firestoreServiceProvider = Provider<FirestoreService>((ref) {
  return FirestoreService();
});

// ============================================
// FIRESTORE SERVICE CLASS
// ============================================
class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Collection references
  CollectionReference get users => _db.collection('users');
  CollectionReference get challenges => _db.collection('challenges');
  CollectionReference get entries => _db.collection('entries');
  CollectionReference get episodes => _db.collection('episodes');
  CollectionReference get chapters => _db.collection('chapters');

  // ============================================
  // USER OPERATIONS
  // ============================================

  /// Create or update user profile
  Future<void> setUser(String uid, Map<String, dynamic> data) async {
    await users.doc(uid).set({
      ...data,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  /// Get user profile
  Future<Map<String, dynamic>?> getUser(String uid) async {
    final doc = await users.doc(uid).get();
    return doc.data() as Map<String, dynamic>?;
  }

  /// Stream user profile
  Stream<DocumentSnapshot> streamUser(String uid) {
    return users.doc(uid).snapshots();
  }

  /// Create new user on first login
  Future<void> createUserOnFirstLogin({
    required String uid,
    required String? phone,
    required String? email,
    required String? displayName,
    required String? photoUrl,
  }) async {
    final userDoc = await users.doc(uid).get();
    
    if (!userDoc.exists) {
      await users.doc(uid).set({
        'uid': uid,
        'phone': phone,
        'email': email,
        'displayName': displayName ?? 'ShowGrid User',
        'photoUrl': photoUrl,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
        'totalEntries': 0,
        'totalLikes': 0,
        'averageScore': 0.0,
        'rank': 0,
        'badges': [],
        'credits': 10, // Starting credits for AI scoring
      });
    }
  }

  // ============================================
  // CHALLENGE OPERATIONS (Fortune Grid)
  // ============================================

  /// Get all active challenges
  Stream<QuerySnapshot> streamActiveChallenges() {
    return challenges
        .where('isActive', isEqualTo: true)
        .where('endDate', isGreaterThan: Timestamp.now())
        .orderBy('endDate')
        .snapshots();
  }

  /// Get challenge by ID
  Future<Map<String, dynamic>?> getChallenge(String challengeId) async {
    final doc = await challenges.doc(challengeId).get();
    return doc.data() as Map<String, dynamic>?;
  }

  // ============================================
  // EPISODE OPERATIONS (Fanverse Grid)
  // ============================================

  /// Get all active episodes
  Stream<QuerySnapshot> streamActiveEpisodes() {
    return episodes
        .where('isActive', isEqualTo: true)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  /// Get episode by ID
  Future<Map<String, dynamic>?> getEpisode(String episodeId) async {
    final doc = await episodes.doc(episodeId).get();
    return doc.data() as Map<String, dynamic>?;
  }

  // ============================================
  // CHAPTER OPERATIONS (GridVoice)
  // ============================================

  /// Get all active chapters
  Stream<QuerySnapshot> streamActiveChapters() {
    return chapters
        .where('isActive', isEqualTo: true)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  /// Get chapter by ID
  Future<Map<String, dynamic>?> getChapter(String chapterId) async {
    final doc = await chapters.doc(chapterId).get();
    return doc.data() as Map<String, dynamic>?;
  }

  // ============================================
  // ENTRY OPERATIONS
  // ============================================

  /// Submit new entry
  Future<String> submitEntry({
    required String userId,
    required String gridType, // 'fortune', 'fanverse', 'gridvoice'
    required String contestId, // challengeId, episodeId, or chapterId
    required String mediaType, // 'photo', 'video', 'audio'
    required String mediaUrl,
    required String thumbnailUrl,
    String? caption,
  }) async {
    final docRef = await entries.add({
      'userId': userId,
      'gridType': gridType,
      'contestId': contestId,
      'mediaType': mediaType,
      'mediaUrl': mediaUrl,
      'thumbnailUrl': thumbnailUrl,
      'caption': caption,
      'createdAt': FieldValue.serverTimestamp(),
      'aiScore': null, // Will be updated after AI scoring
      'humanScore': 0.0,
      'humanRatings': 0,
      'totalScore': 0.0,
      'likes': 0,
      'status': 'pending', // pending, approved, rejected
    });

    // Update user's total entries count
    await users.doc(userId).update({
      'totalEntries': FieldValue.increment(1),
    });

    return docRef.id;
  }

  /// Get entries for a contest
  Stream<QuerySnapshot> streamEntriesForContest(String contestId) {
    return entries
        .where('contestId', isEqualTo: contestId)
        .where('status', isEqualTo: 'approved')
        .orderBy('totalScore', descending: true)
        .snapshots();
  }

  /// Get user's entries
  Stream<QuerySnapshot> streamUserEntries(String userId) {
    return entries
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  /// Update AI score for entry
  Future<void> updateAIScore(String entryId, double aiScore) async {
    final entry = await entries.doc(entryId).get();
    final data = entry.data() as Map<String, dynamic>;
    final humanScore = data['humanScore'] ?? 0.0;
    
    // Calculate total score (60% AI + 40% Human)
    final totalScore = (aiScore * 0.6) + (humanScore * 0.4);
    
    await entries.doc(entryId).update({
      'aiScore': aiScore,
      'totalScore': totalScore,
    });
  }

  /// Add human rating
  Future<void> addHumanRating(String entryId, double rating) async {
    await _db.runTransaction((transaction) async {
      final entryDoc = await transaction.get(entries.doc(entryId));
      final data = entryDoc.data() as Map<String, dynamic>;
      
      final currentHumanScore = data['humanScore'] ?? 0.0;
      final currentRatings = data['humanRatings'] ?? 0;
      final aiScore = data['aiScore'] ?? 0.0;
      
      // Calculate new average
      final newRatings = currentRatings + 1;
      final newHumanScore = 
          ((currentHumanScore * currentRatings) + rating) / newRatings;
      
      // Calculate total score
      final totalScore = (aiScore * 0.6) + (newHumanScore * 0.4);
      
      transaction.update(entries.doc(entryId), {
        'humanScore': newHumanScore,
        'humanRatings': newRatings,
        'totalScore': totalScore,
      });
    });
  }

  /// Like an entry
  Future<void> likeEntry(String entryId, String userId) async {
    // Add to likes subcollection
    await entries.doc(entryId).collection('likes').doc(userId).set({
      'userId': userId,
      'timestamp': FieldValue.serverTimestamp(),
    });
    
    // Increment like count
    await entries.doc(entryId).update({
      'likes': FieldValue.increment(1),
    });
  }

  /// Unlike an entry
  Future<void> unlikeEntry(String entryId, String userId) async {
    await entries.doc(entryId).collection('likes').doc(userId).delete();
    await entries.doc(entryId).update({
      'likes': FieldValue.increment(-1),
    });
  }

  /// Check if user liked entry
  Future<bool> hasUserLiked(String entryId, String userId) async {
    final doc = await entries.doc(entryId).collection('likes').doc(userId).get();
    return doc.exists;
  }

  // ============================================
  // LEADERBOARD / POWERBOARD
  // ============================================

  /// Get top entries for a contest
  Stream<QuerySnapshot> streamLeaderboard(String contestId, {int limit = 50}) {
    return entries
        .where('contestId', isEqualTo: contestId)
        .where('status', isEqualTo: 'approved')
        .orderBy('totalScore', descending: true)
        .limit(limit)
        .snapshots();
  }

  /// Get global leaderboard (all users)
  Stream<QuerySnapshot> streamGlobalLeaderboard({int limit = 100}) {
    return users
        .orderBy('averageScore', descending: true)
        .limit(limit)
        .snapshots();
  }

  // ============================================
  // DISCOVERY FEED
  // ============================================

  /// Get discovery feed (mixed content)
  Stream<QuerySnapshot> streamDiscoveryFeed({int limit = 50}) {
    return entries
        .where('status', isEqualTo: 'approved')
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots();
  }

  /// Get discovery feed by grid type
  Stream<QuerySnapshot> streamDiscoveryByGrid(String gridType, {int limit = 50}) {
    return entries
        .where('gridType', isEqualTo: gridType)
        .where('status', isEqualTo: 'approved')
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots();
  }
}
