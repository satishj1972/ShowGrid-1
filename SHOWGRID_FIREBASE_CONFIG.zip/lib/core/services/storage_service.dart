// lib/core/services/storage_service.dart
// Firebase Storage Service for ShowGrid Media Uploads

import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:video_compress/video_compress.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;
import 'package:uuid/uuid.dart';

// ============================================
// STORAGE SERVICE PROVIDER
// ============================================
final storageServiceProvider = Provider<StorageService>((ref) {
  return StorageService();
});

// ============================================
// UPLOAD PROGRESS PROVIDER
// ============================================
final uploadProgressProvider = StateProvider<double>((ref) => 0.0);

// ============================================
// STORAGE SERVICE CLASS
// ============================================
class StorageService {
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final Uuid _uuid = const Uuid();

  // Storage paths
  String _getPhotoPath(String userId, String contestId) =>
      'entries/$contestId/photos/${userId}_${_uuid.v4()}.jpg';
  
  String _getVideoPath(String userId, String contestId) =>
      'entries/$contestId/videos/${userId}_${_uuid.v4()}.mp4';
  
  String _getAudioPath(String userId, String contestId) =>
      'entries/$contestId/audio/${userId}_${_uuid.v4()}.m4a';
  
  String _getThumbnailPath(String userId, String contestId) =>
      'entries/$contestId/thumbnails/${userId}_${_uuid.v4()}.jpg';
  
  String _getProfilePhotoPath(String userId) =>
      'profiles/$userId/avatar_${_uuid.v4()}.jpg';

  // ============================================
  // PHOTO UPLOAD
  // ============================================

  /// Upload photo with compression
  Future<UploadResult> uploadPhoto({
    required File file,
    required String userId,
    required String contestId,
    Function(double)? onProgress,
  }) async {
    try {
      // Compress image
      final compressedFile = await _compressImage(file);
      
      // Generate path
      final storagePath = _getPhotoPath(userId, contestId);
      
      // Upload
      final downloadUrl = await _uploadFile(
        file: compressedFile,
        path: storagePath,
        contentType: 'image/jpeg',
        onProgress: onProgress,
      );

      // Clean up temp file
      if (compressedFile.path != file.path) {
        await compressedFile.delete();
      }

      return UploadResult(
        success: true,
        downloadUrl: downloadUrl,
        thumbnailUrl: downloadUrl, // Same for photos
      );
    } catch (e) {
      return UploadResult(
        success: false,
        error: 'Failed to upload photo: $e',
      );
    }
  }

  // ============================================
  // VIDEO UPLOAD
  // ============================================

  /// Upload video with compression and thumbnail generation
  Future<UploadResult> uploadVideo({
    required File file,
    required String userId,
    required String contestId,
    Function(double)? onProgress,
  }) async {
    try {
      // Compress video
      final compressedVideo = await _compressVideo(file, onProgress);
      
      // Generate thumbnail
      final thumbnail = await _generateVideoThumbnail(file);
      
      // Upload video
      final videoPath = _getVideoPath(userId, contestId);
      final videoUrl = await _uploadFile(
        file: compressedVideo,
        path: videoPath,
        contentType: 'video/mp4',
        onProgress: onProgress,
      );

      // Upload thumbnail
      String? thumbnailUrl;
      if (thumbnail != null) {
        final thumbPath = _getThumbnailPath(userId, contestId);
        thumbnailUrl = await _uploadFile(
          file: thumbnail,
          path: thumbPath,
          contentType: 'image/jpeg',
        );
        await thumbnail.delete();
      }

      // Clean up
      if (compressedVideo.path != file.path) {
        await compressedVideo.delete();
      }

      return UploadResult(
        success: true,
        downloadUrl: videoUrl,
        thumbnailUrl: thumbnailUrl ?? videoUrl,
      );
    } catch (e) {
      return UploadResult(
        success: false,
        error: 'Failed to upload video: $e',
      );
    }
  }

  // ============================================
  // AUDIO UPLOAD
  // ============================================

  /// Upload audio file
  Future<UploadResult> uploadAudio({
    required File file,
    required String userId,
    required String contestId,
    Function(double)? onProgress,
  }) async {
    try {
      final storagePath = _getAudioPath(userId, contestId);
      
      final downloadUrl = await _uploadFile(
        file: file,
        path: storagePath,
        contentType: 'audio/m4a',
        onProgress: onProgress,
      );

      // Use a default audio thumbnail
      const defaultAudioThumbnail = 
          'https://firebasestorage.googleapis.com/v0/b/YOUR_PROJECT/o/defaults%2Faudio_thumb.png?alt=media';

      return UploadResult(
        success: true,
        downloadUrl: downloadUrl,
        thumbnailUrl: defaultAudioThumbnail,
      );
    } catch (e) {
      return UploadResult(
        success: false,
        error: 'Failed to upload audio: $e',
      );
    }
  }

  // ============================================
  // PROFILE PHOTO UPLOAD
  // ============================================

  /// Upload profile photo
  Future<String?> uploadProfilePhoto({
    required File file,
    required String userId,
    Function(double)? onProgress,
  }) async {
    try {
      final compressedFile = await _compressImage(file, maxSize: 500);
      final storagePath = _getProfilePhotoPath(userId);
      
      final downloadUrl = await _uploadFile(
        file: compressedFile,
        path: storagePath,
        contentType: 'image/jpeg',
        onProgress: onProgress,
      );

      if (compressedFile.path != file.path) {
        await compressedFile.delete();
      }

      return downloadUrl;
    } catch (e) {
      return null;
    }
  }

  // ============================================
  // PRIVATE HELPER METHODS
  // ============================================

  /// Compress image
  Future<File> _compressImage(File file, {int maxSize = 1080}) async {
    final tempDir = await getTemporaryDirectory();
    final targetPath = path.join(
      tempDir.path, 
      '${_uuid.v4()}.jpg'
    );

    final result = await FlutterImageCompress.compressAndGetFile(
      file.absolute.path,
      targetPath,
      minWidth: maxSize,
      minHeight: maxSize,
      quality: 85,
    );

    return result != null ? File(result.path) : file;
  }

  /// Compress video
  Future<File> _compressVideo(File file, Function(double)? onProgress) async {
    // Subscribe to progress
    VideoCompress.compressProgress$.subscribe((progress) {
      onProgress?.call(progress / 100 * 0.5); // First 50% is compression
    });

    final info = await VideoCompress.compressVideo(
      file.path,
      quality: VideoQuality.MediumQuality,
      deleteOrigin: false,
      includeAudio: true,
    );

    return info?.file ?? file;
  }

  /// Generate video thumbnail
  Future<File?> _generateVideoThumbnail(File videoFile) async {
    try {
      final thumbnail = await VideoCompress.getFileThumbnail(
        videoFile.path,
        quality: 75,
        position: 1, // 1 second into video
      );
      return thumbnail;
    } catch (e) {
      return null;
    }
  }

  /// Upload file to Firebase Storage
  Future<String> _uploadFile({
    required File file,
    required String path,
    required String contentType,
    Function(double)? onProgress,
  }) async {
    final ref = _storage.ref().child(path);
    
    final uploadTask = ref.putFile(
      file,
      SettableMetadata(contentType: contentType),
    );

    // Listen to progress
    uploadTask.snapshotEvents.listen((event) {
      final progress = event.bytesTransferred / event.totalBytes;
      // For video, add 50% offset since compression is first half
      onProgress?.call(progress * 0.5 + 0.5);
    });

    // Wait for completion
    await uploadTask;

    // Get download URL
    return await ref.getDownloadURL();
  }

  /// Delete file from storage
  Future<void> deleteFile(String url) async {
    try {
      final ref = _storage.refFromURL(url);
      await ref.delete();
    } catch (e) {
      // File might not exist, ignore
    }
  }
}

// ============================================
// UPLOAD RESULT MODEL
// ============================================
class UploadResult {
  final bool success;
  final String? downloadUrl;
  final String? thumbnailUrl;
  final String? error;

  UploadResult({
    required this.success,
    this.downloadUrl,
    this.thumbnailUrl,
    this.error,
  });
}
