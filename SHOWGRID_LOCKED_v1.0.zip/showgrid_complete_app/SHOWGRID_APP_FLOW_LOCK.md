# 🔒 SHOWGRID APP FLOW LOCK DOCUMENT v1.0
## Complete Navigation & Screen Specification
### Status: LOCKED ✅ | Date: January 2025

---

# 📋 TABLE OF CONTENTS

1. [App Entry Flow](#1-app-entry-flow)
2. [Home (Root Hub)](#2-home-root-hub)
3. [Fortune Flow](#21-fortune-flow)
4. [Fanverse Flow](#22-fanverse-flow)
5. [GridVoice Flow](#23-gridvoice-flow)
6. [Discovery](#3-discovery)
7. [Powerboard](#4-powerboard)
8. [Profile](#5-profile)
9. [Bottom Navigation](#bottom-navigation)
10. [Route Table](#complete-route-table)
11. [Color System](#color-system)
12. [Screen Specifications](#screen-specifications)

---

# 1. APP ENTRY FLOW

```
┌─────────────────┐
│   App Launch    │
└────────┬────────┘
         ↓
┌─────────────────┐
│  1. Splash      │  (3 seconds, auto-navigate)
│  Route: /       │
└────────┬────────┘
         ↓
┌─────────────────┐
│  1.1 Screen 1   │
├─────────────────┤
│  1.11 Screen 2  │  (3 onboarding slides, swipeable)
├─────────────────┤
│  1.111 Screen 3 │
│  Route:         │
│  /onboarding    │
└────────┬────────┘
         ↓
┌─────────────────┐
│  1.2 Login/     │
│  Signup         │  (Email/Mobile input)
│  Route: /login  │
└────────┬────────┘
         ↓
┌─────────────────┐
│  1.2.1 OTP      │
│  Verification   │  (6-digit code)
│  Route: /otp    │
└────────┬────────┘
         ↓
┌─────────────────┐
│    2. HOME      │
│  Route: /home   │
└─────────────────┘
```

### Screen Details:

| Screen | Route | Duration/Action | Next Screen |
|--------|-------|-----------------|-------------|
| Splash | `/` | 3 seconds auto | Onboarding |
| Onboarding | `/onboarding` | 3 slides, tap Next | Login |
| Login | `/login` | User input | OTP |
| OTP | `/otp` | 6-digit verify | Home |

---

# 2. HOME (ROOT HUB)

```
┌─────────────────────────────────────────────────────────┐
│                      2. HOME                            │
│                   Route: /home                          │
├─────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────┐   │
│  │              HERO BANNER                         │   │
│  │    "Three Worlds. One Grid."                    │   │
│  └─────────────────────────────────────────────────┘   │
│                                                         │
│  ┌─────────────────────────────────────────────────┐   │
│  │              SNAPSHOT BAR                        │   │
│  │  🔥 Live | ⭐ AI+People | 🏆 Winners            │   │
│  └─────────────────────────────────────────────────┘   │
│                                                         │
│  ALL GRIDS                                              │
│  ┌─────────────────────────────────────────────────┐   │
│  │  [IMG 60%] │ PARTICIPATE                        │   │
│  │            │ Fortune Event Quest                │   │
│  │            │ → /fortune                         │   │
│  └─────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────┐   │
│  │  [IMG 60%] │ CREATE                             │   │
│  │            │ Magenta Fanverse                   │   │
│  │            │ → /fanverse                        │   │
│  └─────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────┐   │
│  │  [IMG 60%] │ DISCOVER                           │   │
│  │            │ GridVoice TN                       │   │
│  │            │ → /gridvoice                       │   │
│  └─────────────────────────────────────────────────┘   │
│                                                         │
├─────────────────────────────────────────────────────────┤
│  [🏠 Home] [🔍 Discover] [⚡ Powerboard] [👤 Profile]  │
└─────────────────────────────────────────────────────────┘
```

---

# 2.1 FORTUNE FLOW

```
┌──────────────────┐
│   2.1 Fortune    │
│  Route: /fortune │
└────────┬─────────┘
         ↓
┌──────────────────┐
│  2.11 Challenge  │
│  Route:          │
│  /fortune/       │
│  challenge/:id   │
└────────┬─────────┘
         ↓
┌──────────────────┐
│  2.111 Live/     │
│  Upload Page     │
│  Route:          │
│  /fortune/       │
│  live/:id        │
└────────┬─────────┘
         │
    ┌────┴────┬─────────────┐
    ↓         ↓             ↓
┌────────┐ ┌────────┐ ┌──────────┐
│ 2.1111 │ │ 2.1112 │ │  2.1113  │
│ PHOTO  │ │ VIDEO  │ │  UPLOAD  │
│ FLOW   │ │ FLOW   │ │  PAGE    │
└───┬────┘ └───┬────┘ └────┬─────┘
    │          │           │
    ↓          ↓           ↓
┌────────┐ ┌────────┐ ┌──────────┐
│Capture │ │ Record │ │  Select  │
│ Photo  │ │ Video  │ │  File    │
└───┬────┘ └───┬────┘ └────┬─────┘
    ↓          ↓           ↓
┌────────┐ ┌────────┐ ┌──────────┐
│ Take   │ │Record- │ │ Preview  │
│ Photo  │ │  ing   │ │          │
└───┬────┘ └───┬────┘ └────┬─────┘
    ↓          ↓           ↓
┌────────┐ ┌────────┐      │
│Review/ │ │Review/ │      │
│Retake  │ │Retake  │      │
└───┬────┘ └───┬────┘      │
    │          │           │
    └────┬─────┴───────────┘
         ↓
┌──────────────────┐
│     SUBMIT       │
│  → Back to       │
│    Challenge     │
└──────────────────┘
```

### Fortune Challenges (6 Total):

| ID | Icon | Title | Zone | Type |
|----|------|-------|------|------|
| food | 🍜 | Food Grid Hunt | Food Street | Photo/Video |
| style | 👗 | Style Street Runway | Fashion Street | Video |
| family | 👨‍👩‍👧 | Family Frame Quest | Any Zone | Photo |
| college | 🎓 | College Crew Clash | Main Stage | Video |
| night | 🎡 | Night Lights Portrait | Rides/Neon | Photo |
| brand | 🏷️ | Brand Discovery Snap | Any Stall | Photo/Video |

### Fortune Routes:

| Route | Screen | Description |
|-------|--------|-------------|
| `/fortune` | Main | List of 6 challenges |
| `/fortune/challenge/:id` | Challenge | Entry grid, leaderboard, rules |
| `/fortune/live/:id` | Live/Upload | Choose Photo/Video/Upload |
| `/fortune/photo/:id` | Photo Capture | Camera with neon corners |
| `/fortune/video/:id` | Video Record | 60s max recording |
| `/fortune/upload/:id` | Gallery Upload | Pick from gallery |

---

# 2.2 FANVERSE FLOW

```
┌──────────────────┐
│  2.2 Fanverse    │
│ Route: /fanverse │
└────────┬─────────┘
         ↓
┌──────────────────┐
│  2.21 Challenge  │
│  Route:          │
│  /fanverse/      │
│  challenge/:id   │
└────────┬─────────┘
         ↓
┌──────────────────┐
│  2.211 Live/     │
│  Upload Page     │
│  Route:          │
│  /fanverse/      │
│  live/:id        │
└────────┬─────────┘
         │
    ┌────┴────┬─────────────┐
    ↓         ↓             ↓
┌────────┐ ┌────────┐ ┌──────────┐
│ 2.2111 │ │ 2.2112 │ │  2.2113  │
│ PHOTO  │ │ VIDEO  │ │  UPLOAD  │
│ FLOW   │ │ FLOW   │ │  PAGE    │
└───┬────┘ └───┬────┘ └────┬─────┘
    ↓          ↓           ↓
  [Same as Fortune Flow]
         ↓
┌──────────────────┐
│     SUBMIT       │
└──────────────────┘
```

### Fanverse Episodes (6 Total):

| ID | Icon | Title | Show | Type |
|----|------|-------|------|------|
| master-chef | 🍳 | Master Chef Moment | Master Chef | Photo/Video |
| dance-off | 💃 | Dance Reality Pose | Dance Show | Video |
| drama-scene | 🎭 | Drama Scene Recreation | TV Drama | Photo/Video |
| comedy-act | 😂 | Comedy Moment | Stand-up | Video |
| music-cover | 🎤 | Music Cover Challenge | Singing Show | Video |
| fashion-walk | 👠 | Runway Recreation | Fashion Show | Photo/Video |

### Fanverse Routes:

| Route | Screen |
|-------|--------|
| `/fanverse` | Main |
| `/fanverse/challenge/:id` | Episode Detail |
| `/fanverse/live/:id` | Live/Upload Choice |
| `/fanverse/photo/:id` | Photo Capture |
| `/fanverse/video/:id` | Video Record |
| `/fanverse/upload/:id` | Gallery Upload |

---

# 2.3 GRIDVOICE FLOW

```
┌──────────────────┐
│  2.3 GridVoice   │
│ Route: /gridvoice│
└────────┬─────────┘
         ↓
┌──────────────────┐
│  2.31 Challenge  │
│  Route:          │
│  /gridvoice/     │
│  challenge/:id   │
└────────┬─────────┘
         ↓
┌──────────────────┐
│  2.311 Live/     │
│  Upload Page     │
│  Route:          │
│  /gridvoice/     │
│  live/:id        │
└────────┬─────────┘
         │
    ┌────┴────────────┐
    ↓                 ↓
┌─────────┐    ┌───────────┐
│ 2.3111  │    │  2.3112   │
│ AUDIO   │    │  UPLOAD   │
│ FLOW    │    │  FLOW     │
└────┬────┘    └─────┬─────┘
     ↓               ↓
┌─────────┐    ┌───────────┐
│ Start   │    │  Upload   │
│Recording│    │  Audio    │
└────┬────┘    └─────┬─────┘
     ↓               ↓
┌─────────┐    ┌───────────┐
│ Stop    │    │  Preview  │
│Recording│    │           │
└────┬────┘    └─────┬─────┘
     ↓               │
┌─────────┐          │
│ Review/ │          │
│ Retake  │          │
└────┬────┘          │
     │               │
     └───────┬───────┘
             ↓
┌──────────────────┐
│     SUBMIT       │
└──────────────────┘
```

### GridVoice Chapters (4 Total):

| ID | Icon | Title | Theme | Type |
|----|------|-------|-------|------|
| village-tales | 🌿 | Village Tales | Rural Stories | Audio |
| street-stories | 🏙️ | Street Stories | Urban Life | Audio |
| food-memories | 🍛 | Food Memories | Culinary Heritage | Audio |
| festival-voices | 🎉 | Festival Voices | Celebrations | Audio |

### GridVoice Routes:

| Route | Screen |
|-------|--------|
| `/gridvoice` | Main |
| `/gridvoice/challenge/:id` | Chapter Detail |
| `/gridvoice/live/:id` | Record/Upload Choice |
| `/gridvoice/audio/:id` | Audio Recording (3 min max) |
| `/gridvoice/upload/:id` | Audio Upload |

---

# 3. DISCOVERY

```
┌─────────────────────────────────────────────────────────┐
│                    3. DISCOVERY                         │
│                  Route: /discover                       │
├─────────────────────────────────────────────────────────┤
│  FILTERS: [All] [Fortune] [Fanverse] [GridVoice]       │
├─────────────────────────────────────────────────────────┤
│  ┌─────────┐  ┌─────────┐                              │
│  │  Entry  │  │  Entry  │                              │
│  │  Card   │  │  Card   │   ← Grid of all entries     │
│  │ AI 9.35 │  │ AI 9.45 │     from all grids          │
│  └─────────┘  └─────────┘                              │
│  ┌─────────┐  ┌─────────┐                              │
│  │  Entry  │  │  Entry  │                              │
│  │  Card   │  │  Card   │                              │
│  │ AI 9.30 │  │ AI 9.10 │                              │
│  └─────────┘  └─────────┘                              │
├─────────────────────────────────────────────────────────┤
│  [🏠 Home] [🔍 Discover] [⚡ Powerboard] [👤 Profile]  │
└─────────────────────────────────────────────────────────┘
```

### Discovery Features:
- Filter by grid type
- View-only mode (no editing)
- AI score display
- Creator attribution
- Like count

---

# 4. POWERBOARD

```
┌─────────────────────────────────────────────────────────┐
│                   4. POWERBOARD                         │
│                 Route: /powerboard                      │
├─────────────────────────────────────────────────────────┤
│  TABS: [By Challenge] [By Category] [Global] [Seasonal]│
├─────────────────────────────────────────────────────────┤
│                    TOP 3 PODIUM                         │
│         🥈            🥇            🥉                  │
│        #2            #1            #3                   │
│      @user2        @user1        @user3                 │
│       9.35          9.45          9.25                  │
├─────────────────────────────────────────────────────────┤
│  #4  @user4  ............................ 9.10         │
│  #5  @user5  ............................ 9.05         │
│  #6  @user6  ............................ 8.95         │
│  #7  @user7  ............................ 8.85         │
├─────────────────────────────────────────────────────────┤
│  [🏠 Home] [🔍 Discover] [⚡ Powerboard] [👤 Profile]  │
└─────────────────────────────────────────────────────────┘
```

### Powerboard Tabs:
| Tab | Description |
|-----|-------------|
| By Challenge | Rankings per challenge |
| By Category | Rankings by content type |
| Global | All-time rankings |
| Seasonal | Current season rankings |

---

# 5. PROFILE

```
┌─────────────────────────────────────────────────────────┐
│                     5. PROFILE                          │
│                  Route: /profile                        │
├─────────────────────────────────────────────────────────┤
│  ┌──────┐  @your.handle                                │
│  │ Avatar│  Creator since Jan 2025                     │
│  │      │  [RISING CREATOR]                            │
│  └──────┘                                               │
├─────────────────────────────────────────────────────────┤
│  Uploads: 12 | Avg Score: 8.9 | Rank: #24 | Views: 1.2K│
├─────────────────────────────────────────────────────────┤
│  TABS: [5.1 My Uploads] [5.2 Performance] [5.3 Settings]│
├─────────────────────────────────────────────────────────┤
│                                                         │
│  [Content based on selected tab]                       │
│                                                         │
├─────────────────────────────────────────────────────────┤
│  [🏠 Home] [🔍 Discover] [⚡ Powerboard] [👤 Profile]  │
└─────────────────────────────────────────────────────────┘
```

### Profile Tabs:
| Tab | Content |
|-----|---------|
| 5.1 My Uploads | Grid of user's entries |
| 5.2 Performance | Stats by grid (Fortune, Fanverse, GridVoice) |
| 5.3 Settings | Edit Profile, Notifications, Privacy, Help, About |

---

# BOTTOM NAVIGATION

```
┌─────────────────────────────────────────────────────────┐
│  [🏠 Home] [🔍 Discover] [⚡ Powerboard] [👤 Profile]  │
└─────────────────────────────────────────────────────────┘
```

| Icon | Label | Route | Index |
|------|-------|-------|-------|
| 🏠 | Home | `/home` | 0 |
| 🔍 | Discover | `/discover` | 1 |
| ⚡ | Powerboard | `/powerboard` | 2 |
| 👤 | Profile | `/profile` | 3 |

**Behavior:**
- Persistent across all main screens
- Hidden during capture/upload flows
- Active state: Pink (#FF4FD8)
- Inactive state: Muted (#A5A8CF)

---

# COMPLETE ROUTE TABLE

| # | Route | Screen Name | Parent |
|---|-------|-------------|--------|
| 1 | `/` | Splash | - |
| 2 | `/onboarding` | Onboarding | Splash |
| 3 | `/login` | Login | Onboarding |
| 4 | `/otp` | OTP Verification | Login |
| 5 | `/home` | Home | OTP |
| 6 | `/fortune` | Fortune Main | Home |
| 7 | `/fortune/challenge/:id` | Fortune Challenge | Fortune |
| 8 | `/fortune/live/:id` | Fortune Live/Upload | Challenge |
| 9 | `/fortune/photo/:id` | Fortune Photo | Live/Upload |
| 10 | `/fortune/video/:id` | Fortune Video | Live/Upload |
| 11 | `/fortune/upload/:id` | Fortune Upload | Live/Upload |
| 12 | `/fanverse` | Fanverse Main | Home |
| 13 | `/fanverse/challenge/:id` | Fanverse Challenge | Fanverse |
| 14 | `/fanverse/live/:id` | Fanverse Live/Upload | Challenge |
| 15 | `/fanverse/photo/:id` | Fanverse Photo | Live/Upload |
| 16 | `/fanverse/video/:id` | Fanverse Video | Live/Upload |
| 17 | `/fanverse/upload/:id` | Fanverse Upload | Live/Upload |
| 18 | `/gridvoice` | GridVoice Main | Home |
| 19 | `/gridvoice/challenge/:id` | GridVoice Challenge | GridVoice |
| 20 | `/gridvoice/live/:id` | GridVoice Live/Upload | Challenge |
| 21 | `/gridvoice/audio/:id` | GridVoice Audio | Live/Upload |
| 22 | `/gridvoice/upload/:id` | GridVoice Upload | Live/Upload |
| 23 | `/discover` | Discovery | Bottom Nav |
| 24 | `/powerboard` | Powerboard | Bottom Nav |
| 25 | `/profile` | Profile | Bottom Nav |

---

# COLOR SYSTEM

## Base Colors (Brand Book v2.1)
| Name | Hex | Usage |
|------|-----|-------|
| Carbon Black | #050507 | Global background |
| Deep Navy | #0D0F1A | Elevated surfaces |
| Frost White | #FFFFFF | Primary text |
| Soft Grey | #9CA3AF | Secondary text |

## Neon Accents
| Name | Hex | Usage |
|------|-----|-------|
| Violet Core | #6C4AFF | Brand primary |
| Electric Blue | #3B82F6 | CTAs |
| Hyper Pink | #EC4899 | Fanverse theme |
| Neon Mint | #2ED1B8 | Success/Live |
| Pulse Gold | #FACC15 | AI Score, Rewards |

## Grid Theme Colors
| Grid | Primary | Secondary |
|------|---------|-----------|
| Fortune | #FFB84D (Gold) | #FF4FD8 (Pink) |
| Fanverse | #FF4FD8 (Pink) | #9B7DFF (Violet) |
| GridVoice | #5CFFB1 (Mint) | #5CA8FF (Blue) |

---

# SCREEN SPECIFICATIONS

## Capture Screens
| Feature | Photo | Video | Audio |
|---------|-------|-------|-------|
| Max Duration | - | 60 seconds | 180 seconds |
| Corner Guides | Pink neon | Pink neon | - |
| Flash Toggle | ✅ | ✅ | - |
| Camera Switch | ✅ | ✅ | - |
| Timer Display | - | ✅ | ✅ |
| Waveform | - | - | ✅ |
| AI Score | ✅ | ✅ | ✅ |
| Retake | ✅ | ✅ | ✅ |

## AI Score Display
- Range: 0.0 - 10.0
- Color: Gold (#FACC15)
- Format: "AI 9.35"
- Cost: 4 credits per score

---

# 🔒 LOCK CONFIRMATION

This document represents the **LOCKED** state of ShowGrid app flow as of January 2025.

**Total Screens:** 25+
**Total Routes:** 25
**Navigation:** go_router
**State:** Clean Architecture

Any changes to this flow require:
1. Update to this document
2. Version increment
3. Change log entry

---

**Document Version:** 1.0
**Last Updated:** January 2025
**Status:** 🔒 LOCKED
